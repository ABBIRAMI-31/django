from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from .models import UserProfile


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        name = request.POST["name"]
        age = request.POST["age"]
        gmail = request.POST["gmail"]
        mobile = request.POST["mobile"]
        profession = request.POST["profession"]
        department = request.POST["department"]

        # Check whether username already exists
        if User.objects.filter(username=username).exists():
            return render(
                request,
                "accounts/register.html",
                {"error": "Username already exists. Please choose another username."}
            )

        user = User.objects.create_user(
            username=username,
            password=password,
            email=gmail
        )

        UserProfile.objects.create(
            user=user,
            name=name,
            age=age,
            gmail=gmail,
            mobile=mobile,
            profession=profession,
            department=department
        )

        return redirect("/login/")

    return render(request, "accounts/register.html")


def user_login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            return redirect("/dashboard/")

        return render(
            request,
            "accounts/login.html",
            {"error": "Invalid username or password"}
        )

    return render(request, "accounts/login.html")


@login_required
def dashboard(request):
    profile = request.user.userprofile

    return render(
        request,
        "accounts/dashboard.html",
        {"profile": profile}
    )
