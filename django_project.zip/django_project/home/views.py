
from django.shortcuts import render
from django.contrib.auth.decorators import login_required


def home(request):
    return render(request, "home/index.html")


def about(request):
    return render(request, "home/about.html")


@login_required(login_url="/login/")
def explore(request):
    return render(request, "home/explore.html")